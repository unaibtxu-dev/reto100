# Reto 100 - Versión B

Web personal de alimentación, fuerza y actividad. Actualización del 20/10/2026.

## Abrir

Abre Reto100_B.html con un navegador moderno (Chrome, Edge, Firefox o Safari).
El archivo incluye todo lo necesario: datos, estilos, ilustraciones y animaciones.
No requiere instalar dependencias ni estar conectado. Los enlaces de fuentes y
Mercadona sí necesitan Internet. No está publicada en una dirección web.

En un móvil, algunos visores de archivos solo muestran una previsualización y
no ejecutan JavaScript; abre el HTML en un navegador que lo admita. Otra opción
es servir la carpeta en un alojamiento estático HTTPS. No incorpora un servidor.

## Migrar tus registros anteriores

1. En la web anterior: Ajustes -> Exportar copia.
2. En esta versión: Ajustes -> Importar copia y selecciona el JSON.
3. Comprueba tus menús, etiquetas y medidas; exporta una copia nueva.

No dependas de que dos archivos HTML compartan almacenamiento. El navegador
puede tratar cada ruta de archivo por separado. Los registros no se sincronizan
entre dispositivos. Borrar datos del navegador puede borrar los registros.
La copia nueva incluye pasos, paseos, semanas y sesiones editadas.
Las marcas antiguas de entrenamiento se conservan en el JSON pero no se convierten
a series nuevas. No vuelvas a guardar con la versión antigua tras actualizar.

## Novedades

- Pasos totales y minutos de paseo: registro manual por fecha, media de siete días,
  gráfico sin rellenar datos ausentes, referencia editable y exportación CSV.
  No hay conexión a reloj o sensores. El paseo no se vuelve a sumar a los pasos.
  No se calculan calorías quemadas ni se cambian raciones al caminar.
- Plantillas para tres, cuatro y cinco días, por semana. Cuerpo completo;
  torso/pierna; empuje/tiron/pierna + torso/pierna. Puedes añadir un dia,
  asignar una sesión, quitarla y editar ejercicios, series, repeticiones y cargas.
  Aplicar una plantilla conserva sesiones con ejercicios ya completados.
- 20 guías de ejercicios con animaciones SVG originales, controles de inicio,
  final y pausa, explicaciones, errores y favoritos. Son esquemas simplificados,
  no vídeos reales ni una evaluación técnica. Respetan movimiento reducido.
- Lista visual con ilustraciones SVG originales por alimento, modo compacto,
  casillas y calculo semanal/mensual conectado al menu.
- Seis referencias de catálogo para Mercadona: yogur, ñoquis, avena,
  frutos rojos, crema de cacahuete y arroz. Las fuentes independientes están
  enlazadas en las tarjetas. No se afirma stock ni se inventan precios.
  Para otros alimentos hay criterios genéricos, no una referencia verificada.
- Se mantienen el menu editable, las 17 recetas, los registros de progreso,
  la calculadora de discos, el temporizador, la importación y la exportación.

## Como usar el entrenamiento

Abre Entrenamiento, elige la fecha y aplica la plantilla de esa semana.
Para un dia extra pulsa Añadir dia o elige un dia de descanso y asigna sesión.
Pecho-hombro-triceps, espalda-biceps y pierna-abdomen están en el selector.
Los campos se guardan al salir de ellos. La carga de mancuernas es por mancuerna;
en barra se incluye la barra y en maquinas se anota la carga indicada.
Los cambios en una sesión afectan a esa fecha, no a todas las semanas.
La marca real de banca se registra por separado en Progreso.

## Cantidades y seguridad

Las referencias de 2600/2400 kcal y 170 g de proteína son provisionales.
No se ha medido el gasto energético ni el porcentaje de grasa del usuario.
Los formatos consultados sirven para orientar envases y se redondean hacia arriba.
Un formato editado en Ajustes tiene prioridad. Confirmar etiquetas antes de
interpretar los macronutrientes como exactos. Los cambios de rutina pueden cambiar
las raciones base del menu, pero no borran los gramos editados a mano.
No comprar todo el fresco del mes para conservarlo en nevera.
Las guías no sustituyen al entrenador ni al dietista-nutricionista.

## Código y compilación

index.html     - página en varios archivos para editar o publicar.
styles.css     - estilos de la primera versión.
v2.css         - estilos responsive nuevos.
data.js        - alimentos, recetas y referencias originales.
v2-data.js     - ejercicios, plantillas, productos y fuentes nuevas.
app.js         - aplicacion completa, incluida la extension B.
v2-features.js - copia de consulta de la extension integrada en app.js;
                 NO se carga como otro script ni se vuelve a inyectar al compilar.
                 Edita app.js para cambiar el comportamiento.
build.py       - empaqueta los archivos cargados por index.html.
Reto100_B.html  - resultado autónomo listo para abrir.

Para regenerar el HTML autónomo despues de editar:

    python build.py

Para desarrollo local (opcional):

    python -m http.server 8000

y abre http://localhost:8000. No hay herramientas de compilación externas.

## Privacidad

Los datos se guardan bajo reto100_es_v1 en localStorage; el esquema de la
extension esta en enhanced.schema=2. No hay cookies publicitarias, analítica,
llamadas de red automaticas ni transmisión de registros. La copia JSON y el CSV
contienen datos personales: guardalos en un lugar privado.

## Comprobaciones

Pruebas funcionales de navegación, registro de pasos, plantillas, edición de
sesiones, todas las animaciones, filtros, compras, importación y layouts móviles.
Pruebas en Chromium headless renderizando el HTML autónomo. Debido a restricciones
del entorno de pruebas, se simuló el almacén local; verifica y exporta tus datos
antes de cambiar de archivo o navegador. No se ha verificado sensor alguno ni
compatibilidad específica con cada visor de archivos de móvil.
