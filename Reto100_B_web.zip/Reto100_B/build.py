from pathlib import Path
root = Path(__file__).resolve().parent
html = (root / 'index.html').read_text(encoding='utf-8')
for name in ('styles.css', 'v2.css'):
    html = html.replace('<link rel="stylesheet" href="'+name+'">', '<style>\n'+(root/name).read_text(encoding='utf-8')+'\n</style>')
for name in ('data.js', 'v2-data.js', 'app.js'):
    html = html.replace('<script src="'+name+'"></script>', '<script>\n'+(root/name).read_text(encoding='utf-8')+'\n</script>')
(root/'Reto100_B.html').write_text(html, encoding='utf-8')
print('Created Reto100_B.html')
